package d3.env.test;

/*                     <p><center>PUBLIC DOMAIN NOTICE</center></p><p>
This program was prepared by Los Alamos National Security, LLC 
at Los Alamos National Laboratory (LANL) under contract No. 
DE-AC52-06NA25396 with the U.S. Department of Energy (DOE). 
All rights in the program are reserved by the DOE and 
Los Alamos National Security, LLC.  Permission is granted to the 
public to copy and use this software without charge, 
provided that this Notice and any statement of authorship are 
reproduced on all copies.  Neither the U.S. Government nor LANS 
makes any warranty, express or implied, or assumes any liability 
or responsibility for the use of this software.
 */

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.GregorianCalendar;

import org.junit.Test;

import d3.env.TSAGeoMag;

/**<p>
 *  Test values from
 *  <a href ="http://www.ngdc.noaa.gov/geomag/WMM/soft.shtml"> the National GeoPhysical Data Center.</a>.
 *  Click on the WMM2015testvalues.pdf link.
 *  </p><p>
 *  You have to run this test twice. Once with the WMM.COF
 *  file present, and then with it missing. Otherwise the
 *  setCoeff method is never tested.</p>
 *  
 * @version 1.0 Apr 14, 2006
 * @author John St. Ledger
 * @version 1.1 Jan 28, 2009
 * <p>Added 2006 test values.</p>
 * @version 1.2 Jan 5, 2010
 * <p>Updated with the test values for the 2010 WMM.COF coefficients. From page 18 of
 * <i>The US/UK World Magnetic Model for 2010-2015, Preliminary online version containing
 * final WMM2010 model coefficients</i></p>
 * @version 1.3 Jan 15, 2015
 * <p>Updated with the test values for the 2015 WMM.COF coefficients. From the test values WMM2015testvalues.pdf
 * from the WMM web site.</p> * @version 1.4 May 26, 2015
 * <p>Fixed the East-West, North-South bug discovered by Martin Frassl.</p>
 * <p>Updated with the test values for the 2015 WMM.COF coefficients using the 2018 update. From the test values WMM2015testvalues.pdf
 * from the WMM web site.</p> * @version 1.4 May 26, 2015</p>
 * <p>Updated with the test values for the 2020 WMM.COF coefficients using the Dec 2019 update. From the test values WMM2020_TEST_VALUES.txt
 * from the WMM web site.</p> * @version 1.5 Jan 6, 2020</p>
 */
public class TSAGeoMagTest 
{
    TSAGeoMag magModel = new TSAGeoMag();
    /**
     * Test method for {@link d3.env.TSAGeoMag#getDeclination(double, double, double, double)}
     */
    @Test public final void getDeclination() 
    {
	assertEquals(-112.41, magModel.getDeclination( 89, -121, 2020.0, 28) , 5.0E-03);
	assertEquals(-112.41, magModel.getDeclination( 89, -121, 2020.0, 28) , 5.0E-03);
	assertEquals(-112.39, magModel.getDeclination( 89, -121, 2020.0, 27) , 5.0E-03);
	assertEquals( -37.40, magModel.getDeclination( 80,  -96, 2020.0, 48) , 5.0E-03);
	assertEquals(  51.30, magModel.getDeclination( 82,   87, 2020.0, 54) , 5.0E-03);
	assertEquals(   0.71, magModel.getDeclination( 43,   93, 2020.0, 65) , 5.0E-03);
	assertEquals(  -5.78, magModel.getDeclination(-33,  109, 2020.0, 51) , 5.0E-03);
	assertEquals( -15.79, magModel.getDeclination(-59,   -8, 2020.0, 39) , 5.0E-03);
	assertEquals(  28.10, magModel.getDeclination(-50, -103, 2020.0,  3) , 5.0E-03);
	assertEquals(  15.82, magModel.getDeclination(-29, -110, 2020.0, 94) , 5.0E-03);
	assertEquals(   0.12, magModel.getDeclination( 14,  143, 2020.0, 66) , 5.0E-03);
	assertEquals(   1.05, magModel.getDeclination(  0,   21, 2020.0, 18) , 5.0E-03);
	
	assertEquals( 20.16, magModel.getDeclination(-36, -137, 2020.5,  6) , 5.0E-03);
	assertEquals(  0.43, magModel.getDeclination( 26,   81, 2020.5, 63) , 5.0E-03);
	assertEquals( 13.39, magModel.getDeclination( 38, -144, 2020.5, 69) , 5.0E-03);
	assertEquals( 57.40, magModel.getDeclination(-70, -133, 2020.5, 50) , 5.0E-03);
	assertEquals( 15.39, magModel.getDeclination(-52,  -75, 2020.5,  8) , 5.0E-03);
	assertEquals(-32.56, magModel.getDeclination(-66,   17, 2020.5,  8) , 5.0E-03);
	assertEquals(  9.15, magModel.getDeclination(-37,  140, 2020.5, 22) , 5.0E-03);
	assertEquals( 10.83, magModel.getDeclination(-12, -129, 2020.5, 40) , 5.0E-03);
	assertEquals( 11.46, magModel.getDeclination( 33, -118, 2020.5, 44) , 5.0E-03);
	assertEquals( 28.65, magModel.getDeclination(-81,  -67, 2020.5, 50) , 5.0E-03);
	
	assertEquals(-22.29, magModel.getDeclination(-57,    3, 2021.0, 74) , 5.0E-03);
	assertEquals( 14.02, magModel.getDeclination(-24, -122, 2021.0, 46) , 5.0E-03);
	assertEquals(  1.08, magModel.getDeclination( 23,   63, 2021.0, 69) , 5.0E-03);
	assertEquals(  9.74, magModel.getDeclination( -3, -147, 2021.0, 33) , 5.0E-03);
	assertEquals( -6.05, magModel.getDeclination(-72,  -22, 2021.0, 47) , 5.0E-03);
	assertEquals( -1.71, magModel.getDeclination(-14,   99, 2021.0, 62) , 5.0E-03);
	assertEquals(-36.71, magModel.getDeclination( 86,  -46, 2021.0, 83) , 5.0E-03);
	assertEquals(-80.81, magModel.getDeclination(-64,   87, 2021.0, 82) , 5.0E-03);
	assertEquals(-14.32, magModel.getDeclination(-19,   43, 2021.0, 34) , 5.0E-03);
	assertEquals(-59.03, magModel.getDeclination(-81,   40, 2021.0, 56) , 5.0E-03);
	
	assertEquals(  -3.41, magModel.getDeclination(  0,   80, 2021.5, 14) , 5.0E-03);
	assertEquals(  30.36, magModel.getDeclination(-82,  -68, 2021.5, 12) , 5.0E-03);
	assertEquals( -11.54, magModel.getDeclination(-46,  -42, 2021.5, 44) , 5.0E-03);
	assertEquals(   1.23, magModel.getDeclination( 17,   52, 2021.5, 43) , 5.0E-03);
	assertEquals(  -1.71, magModel.getDeclination( 10,   78, 2021.5, 64) , 5.0E-03);
	assertEquals(  12.36, magModel.getDeclination( 33, -145, 2021.5, 12) , 5.0E-03);
	assertEquals(-136.34, magModel.getDeclination(-79,  115, 2021.5, 12) , 5.0E-03);
	assertEquals(  18.10, magModel.getDeclination(-33, -114, 2021.5, 14) , 5.0E-03);
	assertEquals(   2.13, magModel.getDeclination( 29,   66, 2021.5, 19) , 5.0E-03);
	assertEquals(  10.11, magModel.getDeclination(-11,  167, 2021.5, 86) , 5.0E-03);
	
	assertEquals(-16.99, magModel.getDeclination(-66,   -5, 2022.0, 37) , 5.0E-03);
	assertEquals( 15.47, magModel.getDeclination( 72, -115, 2022.0, 67) , 5.0E-03);
	assertEquals(  6.56, magModel.getDeclination( 22,  174, 2022.0, 44) , 5.0E-03);
	assertEquals(  1.43, magModel.getDeclination( 54,  178, 2022.0, 54) , 5.0E-03);
	assertEquals(-47.43, magModel.getDeclination(-43,   50, 2022.0, 57) , 5.0E-03);
	assertEquals( 24.32, magModel.getDeclination(-43, -111, 2022.0, 44) , 5.0E-03);
	assertEquals( 57.08, magModel.getDeclination(-63,  178, 2022.0, 12) , 5.0E-03);
	assertEquals(  8.76, magModel.getDeclination( 27, -169, 2022.0, 38) , 5.0E-03);
	assertEquals(-17.63, magModel.getDeclination( 59,  -77, 2022.0, 61) , 5.0E-03);
	assertEquals(-14.09, magModel.getDeclination(-47,  -32, 2022.0, 67) , 5.0E-03);
	
	assertEquals(  18.95, magModel.getDeclination(  62,   53, 2022.5,  8) , 5.0E-03);
	assertEquals( -15.94, magModel.getDeclination( -68,   -7, 2022.5, 77) , 5.0E-03);
	assertEquals(   7.79, magModel.getDeclination(  -5,  159, 2022.5, 98) , 5.0E-03);
	assertEquals(  15.68, magModel.getDeclination( -29, -107, 2022.5, 34) , 5.0E-03);
	assertEquals(   1.78, magModel.getDeclination(  27,   65, 2022.5, 60) , 5.0E-03);
	assertEquals(-101.49, magModel.getDeclination( -72,   95, 2022.5, 73) , 5.0E-03);
	assertEquals(  18.38, magModel.getDeclination( -46,  -85, 2022.5, 96) , 5.0E-03);
	assertEquals( -16.65, magModel.getDeclination( -13,  -59, 2022.5,  0) , 5.0E-03);
	assertEquals(   1.92, magModel.getDeclination(  66, -178, 2022.5, 16) , 5.0E-03);
	assertEquals( -64.66, magModel.getDeclination( -87,   38, 2022.5, 72) , 5.0E-03);
	
	assertEquals(   5.20, magModel.getDeclination(  20 , 167, 2023.0, 49) , 5.0E-03);
	assertEquals(  -7.26, magModel.getDeclination(   5 , -13, 2023.0, 71) , 5.0E-03);
	assertEquals(  -0.56, magModel.getDeclination(  14 ,  65, 2023.0, 95) , 5.0E-03);
	assertEquals(  41.76, magModel.getDeclination( -85 , -79, 2023.0, 86) , 5.0E-03);
	assertEquals(  -3.87, magModel.getDeclination( -36 , -64, 2023.0, 30) , 5.0E-03);
	assertEquals( -14.54, magModel.getDeclination(  79 , 125, 2023.0, 75) , 5.0E-03);
	assertEquals( -15.22, magModel.getDeclination(   6 , -32, 2023.0, 21) , 5.0E-03);
	assertEquals(  30.36, magModel.getDeclination( -76 , -75, 2023.0,  1) , 5.0E-03);
	assertEquals( -11.94, magModel.getDeclination( -46 , -41, 2023.0, 45) , 5.0E-03);
	assertEquals( -24.12, magModel.getDeclination( -22 , -21, 2023.0, 11) , 5.0E-03);
	
	assertEquals(  16.20, magModel.getDeclination(  54 , -120, 2023.5, 28) , 5.0E-03);
	assertEquals(  40.48, magModel.getDeclination( -58 ,  156, 2023.5, 68) , 5.0E-03);
	assertEquals(  29.86, magModel.getDeclination( -65 ,  -88, 2023.5, 39) , 5.0E-03);
	assertEquals( -13.98, magModel.getDeclination( -23 ,   81, 2023.5, 27) , 5.0E-03);
	assertEquals(   1.08, magModel.getDeclination(  34 ,    0, 2023.5, 11) , 5.0E-03);
	assertEquals( -66.98, magModel.getDeclination( -62 ,   65, 2023.5, 72) , 5.0E-03);
	assertEquals(  61.19, magModel.getDeclination(  86 ,   70, 2023.5, 55) , 5.0E-03);
	assertEquals(   0.36, magModel.getDeclination(  32 ,  163, 2023.5, 59) , 5.0E-03);
	assertEquals(  -9.39, magModel.getDeclination(  48 ,  148, 2023.5, 65) , 5.0E-03);
	assertEquals(   4.49, magModel.getDeclination(  30 ,   28, 2023.5, 95) , 5.0E-03);
	
	assertEquals(   8.86, magModel.getDeclination( -60 ,  -59, 2024.0, 95) , 5.0E-03);
	assertEquals( -54.29, magModel.getDeclination( -70 ,   42, 2024.0, 95) , 5.0E-03);
	assertEquals( -82.22, magModel.getDeclination(  87 , -154, 2024.0, 50) , 5.0E-03);
	assertEquals(   3.94, magModel.getDeclination(  32 ,   19, 2024.0, 58) , 5.0E-03);
	assertEquals(  -2.62, magModel.getDeclination(  34 ,  -13, 2024.0, 57) , 5.0E-03);
	assertEquals( -63.51, magModel.getDeclination( -76 ,   49, 2024.0, 38) , 5.0E-03);
	assertEquals(  31.57, magModel.getDeclination( -50 , -179, 2024.0, 49) , 5.0E-03);
	assertEquals(  38.07, magModel.getDeclination( -55 , -171, 2024.0, 90) , 5.0E-03);
	assertEquals(  -5.00, magModel.getDeclination(  42 ,  -19, 2024.0, 41) , 5.0E-03);
	assertEquals(  -6.60, magModel.getDeclination(  46 ,  -22, 2024.0, 19) , 5.0E-03);
	
	assertEquals(   9.21, magModel.getDeclination(  13 , -132, 2024.5, 31) , 5.0E-03);
	assertEquals(   7.16, magModel.getDeclination(  -2 ,  158, 2024.5, 93) , 5.0E-03);
	assertEquals( -55.63, magModel.getDeclination( -76 ,   40, 2024.5, 51) , 5.0E-03);
	assertEquals(  10.52, magModel.getDeclination(  22 , -132, 2024.5, 64) , 5.0E-03);
	assertEquals( -62.60, magModel.getDeclination( -65 ,   55, 2024.5, 26) , 5.0E-03);
	assertEquals( -13.34, magModel.getDeclination( -21 ,   32, 2024.5, 66) , 5.0E-03);
	assertEquals(   9.39, magModel.getDeclination(   9 , -172, 2024.5, 18) , 5.0E-03);
	assertEquals(  29.81, magModel.getDeclination(  88 ,   26, 2024.5, 63) , 5.0E-03);
	assertEquals(   0.61, magModel.getDeclination(  17 ,    5, 2024.5, 33) , 5.0E-03);
	assertEquals(   4.63, magModel.getDeclination( -18 ,  138, 2024.5, 77) , 5.0E-03);
	
    }
    
    /**
     * Test method for {@link d3.env.TSAGeoMag#getDipAngle(double, double, double, double)}
     */
    @Test public final void getDipAngle() 
    {
	assertEquals( 88.46, magModel.getDipAngle( 89, -121, 2020.0, 28) , 5.0E-03);
	assertEquals( 88.03, magModel.getDipAngle( 80,  -96, 2020.0, 48) , 5.0E-03);
	assertEquals( 87.48, magModel.getDipAngle( 82,   87, 2020.0, 54) , 5.0E-03);
	assertEquals( 63.87, magModel.getDipAngle( 43,   93, 2020.0, 65) , 5.0E-03);
	assertEquals(-67.64, magModel.getDipAngle(-33,  109, 2020.0, 51) , 5.0E-03);
	assertEquals(-58.82, magModel.getDipAngle(-59,   -8, 2020.0, 39) , 5.0E-03);
	assertEquals(-55.01, magModel.getDipAngle(-50, -103, 2020.0,  3) , 5.0E-03);
	assertEquals(-38.38, magModel.getDipAngle(-29, -110, 2020.0, 94) , 5.0E-03);
	assertEquals( 13.08, magModel.getDipAngle( 14,  143, 2020.0, 66) , 5.0E-03);
	assertEquals(-26.46, magModel.getDipAngle(  0,   21, 2020.0, 18) , 5.0E-03);
	
	assertEquals(-52.21, magModel.getDipAngle(-36, -137, 2020.5,  6) , 5.0E-03);
	assertEquals( 40.84, magModel.getDipAngle( 26,   81, 2020.5, 63) , 5.0E-03);
	assertEquals( 56.99, magModel.getDipAngle( 38, -144, 2020.5, 69) , 5.0E-03);
	assertEquals(-72.18, magModel.getDipAngle(-70, -133, 2020.5, 50) , 5.0E-03);
	assertEquals(-49.50, magModel.getDipAngle(-52,  -75, 2020.5,  8) , 5.0E-03);
	assertEquals(-59.78, magModel.getDipAngle(-66,   17, 2020.5,  8) , 5.0E-03);
	assertEquals(-68.61, magModel.getDipAngle(-37,  140, 2020.5, 22) , 5.0E-03);
	assertEquals(-15.68, magModel.getDipAngle(-12, -129, 2020.5, 40) , 5.0E-03);
	assertEquals( 57.97, magModel.getDipAngle( 33, -118, 2020.5, 44) , 5.0E-03);
	assertEquals(-67.74, magModel.getDipAngle(-81,  -67, 2020.5, 50) , 5.0E-03);
	
	assertEquals(-59.07, magModel.getDipAngle(-57,    3, 2021.0, 74) , 5.0E-03);
	assertEquals(-34.29, magModel.getDipAngle(-24, -122, 2021.0, 46) , 5.0E-03);
	assertEquals( 35.82, magModel.getDipAngle( 23,   63, 2021.0, 69) , 5.0E-03);
	assertEquals( -2.35, magModel.getDipAngle( -3, -147, 2021.0, 33) , 5.0E-03);
	assertEquals(-61.27, magModel.getDipAngle(-72,  -22, 2021.0, 47) , 5.0E-03);
	assertEquals(-45.11, magModel.getDipAngle(-14,   99, 2021.0, 62) , 5.0E-03);
	assertEquals( 86.83, magModel.getDipAngle( 86,  -46, 2021.0, 83) , 5.0E-03);
	assertEquals(-75.25, magModel.getDipAngle(-64,   87, 2021.0, 82) , 5.0E-03);
	assertEquals(-52.47, magModel.getDipAngle(-19,   43, 2021.0, 34) , 5.0E-03);
	assertEquals(-68.54, magModel.getDipAngle(-81,   40, 2021.0, 56) , 5.0E-03);
	
	assertEquals(-17.32, magModel.getDipAngle(  0,   80, 2021.5, 14) , 5.0E-03);
	assertEquals(-68.18, magModel.getDipAngle(-82,  -68, 2021.5, 12) , 5.0E-03);
	assertEquals(-53.82, magModel.getDipAngle(-46,  -42, 2021.5, 44) , 5.0E-03);
	assertEquals( 23.87, magModel.getDipAngle( 17,   52, 2021.5, 43) , 5.0E-03);
	assertEquals(  7.37, magModel.getDipAngle( 10,   78, 2021.5, 64) , 5.0E-03);
	assertEquals( 52.51, magModel.getDipAngle( 33, -145, 2021.5, 12) , 5.0E-03);
	assertEquals(-77.43, magModel.getDipAngle(-79,  115, 2021.5, 12) , 5.0E-03);
	assertEquals(-44.23, magModel.getDipAngle(-33, -114, 2021.5, 14) , 5.0E-03);
	assertEquals( 45.97, magModel.getDipAngle( 29,   66, 2021.5, 19) , 5.0E-03);
	assertEquals(-31.45, magModel.getDipAngle(-11,  167, 2021.5, 86) , 5.0E-03);
	
	assertEquals(-59.27, magModel.getDipAngle(-66,   -5, 2022.0, 37) , 5.0E-03);
	assertEquals( 85.19, magModel.getDipAngle( 72, -115, 2022.0, 67) , 5.0E-03);
	assertEquals( 31.91, magModel.getDipAngle( 22,  174, 2022.0, 44) , 5.0E-03);
	assertEquals( 65.41, magModel.getDipAngle( 54,  178, 2022.0, 54) , 5.0E-03);
	assertEquals(-62.96, magModel.getDipAngle(-43,   50, 2022.0, 57) , 5.0E-03);
	assertEquals(-52.71, magModel.getDipAngle(-43, -111, 2022.0, 44) , 5.0E-03);
	assertEquals(-79.33, magModel.getDipAngle(-63,  178, 2022.0, 12) , 5.0E-03);
	assertEquals( 42.60, magModel.getDipAngle( 27, -169, 2022.0, 38) , 5.0E-03);
	assertEquals( 79.04, magModel.getDipAngle( 59,  -77, 2022.0, 61) , 5.0E-03);
	assertEquals(-57.63, magModel.getDipAngle(-47,  -32, 2022.0, 67) , 5.0E-03);
	
	assertEquals( 76.54, magModel.getDipAngle(  62,   53, 2022.5,  8) , 5.0E-03);
	assertEquals(-60.00, magModel.getDipAngle( -68,   -7, 2022.5, 77) , 5.0E-03);
	assertEquals(-23.04, magModel.getDipAngle(  -5,  159, 2022.5, 98) , 5.0E-03);
	assertEquals(-37.65, magModel.getDipAngle( -29, -107, 2022.5, 34) , 5.0E-03);
	assertEquals( 42.84, magModel.getDipAngle(  27,   65, 2022.5, 60) , 5.0E-03);
	assertEquals(-76.44, magModel.getDipAngle( -72,   95, 2022.5, 73) , 5.0E-03);
	assertEquals(-47.38, magModel.getDipAngle( -46,  -85, 2022.5, 96) , 5.0E-03);
	assertEquals(-13.41, magModel.getDipAngle( -13,  -59, 2022.5,  0) , 5.0E-03);
	assertEquals( 75.67, magModel.getDipAngle(  66, -178, 2022.5, 16) , 5.0E-03);
	assertEquals(-71.05, magModel.getDipAngle( -87,   38, 2022.5, 72) , 5.0E-03);
	
	assertEquals( 26.85, magModel.getDipAngle(  20 , 167, 2023.0, 49) , 5.0E-03);
	assertEquals(-17.38, magModel.getDipAngle(   5 , -13, 2023.0, 71) , 5.0E-03);
	assertEquals( 17.52, magModel.getDipAngle(  14 ,  65, 2023.0, 95) , 5.0E-03);
	assertEquals(-70.36, magModel.getDipAngle( -85 , -79, 2023.0, 86) , 5.0E-03);
	assertEquals(-39.40, magModel.getDipAngle( -36 , -64, 2023.0, 30) , 5.0E-03);
	assertEquals( 87.30, magModel.getDipAngle(  79 , 125, 2023.0, 75) , 5.0E-03);
	assertEquals( -7.26, magModel.getDipAngle(   6 , -32, 2023.0, 21) , 5.0E-03);
	assertEquals(-65.32, magModel.getDipAngle( -76 , -75, 2023.0,  1) , 5.0E-03);
	assertEquals(-54.45, magModel.getDipAngle( -46 , -41, 2023.0, 45) , 5.0E-03);
	assertEquals(-56.82, magModel.getDipAngle( -22 , -21, 2023.0, 11) , 5.0E-03);
	
	assertEquals(  74.02, magModel.getDipAngle(  54 , -120, 2023.5, 28) , 5.0E-03);
	assertEquals( -81.60, magModel.getDipAngle( -58 ,  156, 2023.5, 68) , 5.0E-03);
	assertEquals( -60.29, magModel.getDipAngle( -65 ,  -88, 2023.5, 39) , 5.0E-03);
	assertEquals( -58.52, magModel.getDipAngle( -23 ,   81, 2023.5, 27) , 5.0E-03);
	assertEquals(  46.69, magModel.getDipAngle(  34 ,    0, 2023.5, 11) , 5.0E-03);
	assertEquals( -68.38, magModel.getDipAngle( -62 ,   65, 2023.5, 72) , 5.0E-03);
	assertEquals(  87.51, magModel.getDipAngle(  86 ,   70, 2023.5, 55) , 5.0E-03);
	assertEquals(  43.05, magModel.getDipAngle(  32 ,  163, 2023.5, 59) , 5.0E-03);
	assertEquals(  61.70, magModel.getDipAngle(  48 ,  148, 2023.5, 65) , 5.0E-03);
	assertEquals(  44.12, magModel.getDipAngle(  30 ,   28, 2023.5, 95) , 5.0E-03);
	
	assertEquals( -55.03, magModel.getDipAngle( -60 ,  -59, 2024.0, 95) , 5.0E-03);
	assertEquals( -64.59, magModel.getDipAngle( -70 ,   42, 2024.0, 95) , 5.0E-03);
	assertEquals(  89.39, magModel.getDipAngle(  87 , -154, 2024.0, 50) , 5.0E-03);
	assertEquals(  45.89, magModel.getDipAngle(  32 ,   19, 2024.0, 58) , 5.0E-03);
	assertEquals(  45.83, magModel.getDipAngle(  34 ,  -13, 2024.0, 57) , 5.0E-03);
	assertEquals( -67.40, magModel.getDipAngle( -76 ,   49, 2024.0, 38) , 5.0E-03);
	assertEquals( -71.40, magModel.getDipAngle( -50 , -179, 2024.0, 49) , 5.0E-03);
	assertEquals( -72.91, magModel.getDipAngle( -55 , -171, 2024.0, 90) , 5.0E-03);
	assertEquals(  56.57, magModel.getDipAngle(  42 ,  -19, 2024.0, 41) , 5.0E-03);
	assertEquals(  61.04, magModel.getDipAngle(  46 ,  -22, 2024.0, 19) , 5.0E-03);
	
	assertEquals(  31.51, magModel.getDipAngle(  13 , -132, 2024.5, 31) , 5.0E-03);
	assertEquals( -17.78, magModel.getDipAngle(  -2 ,  158, 2024.5, 93) , 5.0E-03);
	assertEquals( -66.27, magModel.getDipAngle( -76 ,   40, 2024.5, 51) , 5.0E-03);
	assertEquals(  43.88, magModel.getDipAngle(  22 , -132, 2024.5, 64) , 5.0E-03);
	assertEquals( -65.67, magModel.getDipAngle( -65 ,   55, 2024.5, 26) , 5.0E-03);
	assertEquals( -56.95, magModel.getDipAngle( -21 ,   32, 2024.5, 66) , 5.0E-03);
	assertEquals(  15.78, magModel.getDipAngle(   9 , -172, 2024.5, 18) , 5.0E-03);
	assertEquals(  87.38, magModel.getDipAngle(  88 ,   26, 2024.5, 63) , 5.0E-03);
	assertEquals(  13.58, magModel.getDipAngle(  17 ,    5, 2024.5, 33) , 5.0E-03);
	assertEquals( -47.71, magModel.getDipAngle( -18 ,  138, 2024.5, 77) , 5.0E-03);
    }
    /**
     * Test method for {@link d3.env.TSAGeoMag#getHorizontalIntensity(double, double, double, double)} in nT
     * and {@link d3.env.TSAGeoMag#getHorizontalIntensity(double, double)} in nT
     */
    @Test public final void getHorizontalIntensity() 
    {
	assertEquals( 1510.0, magModel.getHorizontalIntensity( 89, -121, 2020.0, 28) , 5.0E-02);
	assertEquals( 1910.8, magModel.getHorizontalIntensity( 80,  -96, 2020.0, 48) , 5.0E-02);
	assertEquals( 2487.8, magModel.getHorizontalIntensity( 82,   87, 2020.0, 54) , 5.0E-02);
	assertEquals(24377.2, magModel.getHorizontalIntensity( 43,   93, 2020.0, 65) , 5.0E-02);
	assertEquals(21666.6, magModel.getHorizontalIntensity(-33,  109, 2020.0, 51) , 5.0E-02);
	assertEquals(14933.4, magModel.getHorizontalIntensity(-59,   -8, 2020.0, 39) , 5.0E-02);
	assertEquals(22315.5, magModel.getHorizontalIntensity(-50, -103, 2020.0,  3) , 5.0E-02);
	assertEquals(24392.0, magModel.getHorizontalIntensity(-29, -110, 2020.0, 94) , 5.0E-02);
	assertEquals(34916.9, magModel.getHorizontalIntensity( 14,  143, 2020.0, 66) , 5.0E-02);
	assertEquals(29316.1, magModel.getHorizontalIntensity(  0,   21, 2020.0, 18) , 5.0E-02);
	
	assertEquals(25511.4, magModel.getHorizontalIntensity(-36, -137, 2020.5,  6) , 5.0E-02);
	assertEquals(34738.7, magModel.getHorizontalIntensity( 26,   81, 2020.5, 63) , 5.0E-02);
	assertEquals(23279.9, magModel.getHorizontalIntensity( 38, -144, 2020.5, 69) , 5.0E-02);
	assertEquals(16597.2, magModel.getHorizontalIntensity(-70, -133, 2020.5, 50) , 5.0E-02);
	assertEquals(20299.7, magModel.getHorizontalIntensity(-52,  -75, 2020.5,  8) , 5.0E-02);
	assertEquals(18089.7, magModel.getHorizontalIntensity(-66,   17, 2020.5,  8) , 5.0E-02);
	assertEquals(21705.2, magModel.getHorizontalIntensity(-37,  140, 2020.5, 22) , 5.0E-02);
	assertEquals(29295.6, magModel.getHorizontalIntensity(-12, -129, 2020.5, 40) , 5.0E-02);
	assertEquals(23890.9, magModel.getHorizontalIntensity( 33, -118, 2020.5, 44) , 5.0E-02);
	assertEquals(18332.1, magModel.getHorizontalIntensity(-81,  -67, 2020.5, 50) , 5.0E-02);
	
	assertEquals(14296.6, magModel.getHorizontalIntensity(-57,    3, 2021.0, 74) , 5.0E-02);
	assertEquals(26836.5, magModel.getHorizontalIntensity(-24, -122, 2021.0, 46) , 5.0E-02);
	assertEquals(34456.5, magModel.getHorizontalIntensity( 23,   63, 2021.0, 69) , 5.0E-02);
	assertEquals(31138.6, magModel.getHorizontalIntensity( -3, -147, 2021.0, 33) , 5.0E-02);
	assertEquals(18455.7, magModel.getHorizontalIntensity(-72,  -22, 2021.0, 47) , 5.0E-02);
	assertEquals(33227.7, magModel.getHorizontalIntensity(-14,   99, 2021.0, 62) , 5.0E-02);
	assertEquals( 3004.8, magModel.getHorizontalIntensity( 86,  -46, 2021.0, 83) , 5.0E-02);
	assertEquals(14087.8, magModel.getHorizontalIntensity(-64,   87, 2021.0, 82) , 5.0E-02);
	assertEquals(19947.3, magModel.getHorizontalIntensity(-19,   43, 2021.0, 34) , 5.0E-02);
	assertEquals(17872.0, magModel.getHorizontalIntensity(-81,   40, 2021.0, 56) , 5.0E-02);
	
	assertEquals(39316.2, magModel.getHorizontalIntensity(  0,   80, 2021.5, 14) , 5.0E-02);
	assertEquals(18536.8, magModel.getHorizontalIntensity(-82,  -68, 2021.5, 12) , 5.0E-02);
	assertEquals(14450.9, magModel.getHorizontalIntensity(-46,  -42, 2021.5, 44) , 5.0E-02);
	assertEquals(35904.4, magModel.getHorizontalIntensity( 17,   52, 2021.5, 43) , 5.0E-02);
	assertEquals(39311.5, magModel.getHorizontalIntensity( 10,   78, 2021.5, 64) , 5.0E-02);
	assertEquals(24878.3, magModel.getHorizontalIntensity( 33, -145, 2021.5, 12) , 5.0E-02);
	assertEquals(12997.3, magModel.getHorizontalIntensity(-79,  115, 2021.5, 12) , 5.0E-02);
	assertEquals(24820.9, magModel.getHorizontalIntensity(-33, -114, 2021.5, 14) , 5.0E-02);
	assertEquals(32640.6, magModel.getHorizontalIntensity( 29,   66, 2021.5, 19) , 5.0E-02);
	assertEquals(33191.7, magModel.getHorizontalIntensity(-11,  167, 2021.5, 86) , 5.0E-02);
	
	assertEquals(17152.6, magModel.getHorizontalIntensity(-66,   -5, 2022.0, 37) , 5.0E-02);
	assertEquals( 4703.2, magModel.getHorizontalIntensity( 72, -115, 2022.0, 67) , 5.0E-02);
	assertEquals(28859.7, magModel.getHorizontalIntensity( 22,  174, 2022.0, 44) , 5.0E-02);
	assertEquals(20631.2, magModel.getHorizontalIntensity( 54,  178, 2022.0, 54) , 5.0E-02);
	assertEquals(16769.3, magModel.getHorizontalIntensity(-43,   50, 2022.0, 57) , 5.0E-02);
	assertEquals(22656.4, magModel.getHorizontalIntensity(-43, -111, 2022.0, 44) , 5.0E-02);
	assertEquals(11577.2, magModel.getHorizontalIntensity(-63,  178, 2022.0, 12) , 5.0E-02);
	assertEquals(26202.3, magModel.getHorizontalIntensity( 27, -169, 2022.0, 38) , 5.0E-02);
	assertEquals(10595.8, magModel.getHorizontalIntensity( 59,  -77, 2022.0, 61) , 5.0E-02);
	assertEquals(13056.5, magModel.getHorizontalIntensity(-47,  -32, 2022.0, 67) , 5.0E-02);
	
	assertEquals(13043.3, magModel.getHorizontalIntensity(  62,   53, 2022.5,  8) , 5.0E-02);
	assertEquals(17268.3, magModel.getHorizontalIntensity( -68,   -7, 2022.5, 77) , 5.0E-02);
	assertEquals(33927.0, magModel.getHorizontalIntensity(  -5,  159, 2022.5, 98) , 5.0E-02);
	assertEquals(24657.0, magModel.getHorizontalIntensity( -29, -107, 2022.5, 34) , 5.0E-02);
	assertEquals(32954.8, magModel.getHorizontalIntensity(  27,   65, 2022.5, 60) , 5.0E-02);
	assertEquals(13362.8, magModel.getHorizontalIntensity( -72,   95, 2022.5, 73) , 5.0E-02);
	assertEquals(20165.1, magModel.getHorizontalIntensity( -46,  -85, 2022.5, 96) , 5.0E-02);
	assertEquals(22751.7, magModel.getHorizontalIntensity( -13,  -59, 2022.5,  0) , 5.0E-02);
	assertEquals(13812.2, magModel.getHorizontalIntensity(  66, -178, 2022.5, 16) , 5.0E-02);
	assertEquals(16666.4, magModel.getHorizontalIntensity( -87,   38, 2022.5, 72) , 5.0E-02);
	
	assertEquals( 30223.6, magModel.getHorizontalIntensity(  20 , 167, 2023.0, 49) , 5.0E-02);
	assertEquals( 28445.5, magModel.getHorizontalIntensity(   5 , -13, 2023.0, 71) , 5.0E-02);
	assertEquals( 36805.8, magModel.getHorizontalIntensity(  14 ,  65, 2023.0, 95) , 5.0E-02);
	assertEquals( 16888.7, magModel.getHorizontalIntensity( -85 , -79, 2023.0, 86) , 5.0E-02);
	assertEquals( 17735.3, magModel.getHorizontalIntensity( -36 , -64, 2023.0, 30) , 5.0E-02);
	assertEquals(  2692.1, magModel.getHorizontalIntensity(  79 , 125, 2023.0, 75) , 5.0E-02);
	assertEquals( 28634.3, magModel.getHorizontalIntensity(   6 , -32, 2023.0, 21) , 5.0E-02);
	assertEquals( 19700.9, magModel.getHorizontalIntensity( -76 , -75, 2023.0,  1) , 5.0E-02);
	assertEquals( 14187.4, magModel.getHorizontalIntensity( -46 , -41, 2023.0, 45) , 5.0E-02);
	assertEquals( 13972.9, magModel.getHorizontalIntensity( -22 , -21, 2023.0, 11) , 5.0E-02);
	
	assertEquals( 15158.8, magModel.getHorizontalIntensity(  54 , -120, 2023.5, 28) , 5.0E-02);
	assertEquals(  9223.1, magModel.getHorizontalIntensity( -58 ,  156, 2023.5, 68) , 5.0E-02);
	assertEquals( 20783.0, magModel.getHorizontalIntensity( -65 ,  -88, 2023.5, 39) , 5.0E-02);
	assertEquals( 25568.2, magModel.getHorizontalIntensity( -23 ,   81, 2023.5, 27) , 5.0E-02);
	assertEquals( 29038.8, magModel.getHorizontalIntensity(  34 ,    0, 2023.5, 11) , 5.0E-02);
	assertEquals( 17485.0, magModel.getHorizontalIntensity( -62 ,   65, 2023.5, 72) , 5.0E-02);
	assertEquals(  2424.9, magModel.getHorizontalIntensity(  86 ,   70, 2023.5, 55) , 5.0E-02);
	assertEquals( 28170.6, magModel.getHorizontalIntensity(  32 ,  163, 2023.5, 59) , 5.0E-02);
	assertEquals( 23673.8, magModel.getHorizontalIntensity(  48 ,  148, 2023.5, 65) , 5.0E-02);
	assertEquals( 29754.7, magModel.getHorizontalIntensity(  30 ,   28, 2023.5, 95) , 5.0E-02);
	
	assertEquals( 18317.9, magModel.getHorizontalIntensity( -60 ,  -59, 2024.0, 95) , 5.0E-02);
	assertEquals( 18188.3, magModel.getHorizontalIntensity( -70 ,   42, 2024.0, 95) , 5.0E-02);
	assertEquals(   597.9, magModel.getHorizontalIntensity(  87 , -154, 2024.0, 50) , 5.0E-02);
	assertEquals( 29401.0, magModel.getHorizontalIntensity(  32 ,   19, 2024.0, 58) , 5.0E-02);
	assertEquals( 28188.3, magModel.getHorizontalIntensity(  34 ,  -13, 2024.0, 57) , 5.0E-02);
	assertEquals( 18425.8, magModel.getHorizontalIntensity( -76 ,   49, 2024.0, 38) , 5.0E-02);
	assertEquals( 18112.2, magModel.getHorizontalIntensity( -50 , -179, 2024.0, 49) , 5.0E-02);
	assertEquals( 16409.7, magModel.getHorizontalIntensity( -55 , -171, 2024.0, 90) , 5.0E-02);
	assertEquals( 24410.2, magModel.getHorizontalIntensity(  42 ,  -19, 2024.0, 41) , 5.0E-02);
	assertEquals( 22534.0, magModel.getHorizontalIntensity(  46 ,  -22, 2024.0, 19) , 5.0E-02);
	
	assertEquals( 28413.4, magModel.getHorizontalIntensity(  13 , -132, 2024.5, 31) , 5.0E-02);
	assertEquals( 34124.3, magModel.getHorizontalIntensity(  -2 ,  158, 2024.5, 93) , 5.0E-02);
	assertEquals( 18529.2, magModel.getHorizontalIntensity( -76 ,   40, 2024.5, 51) , 5.0E-02);
	assertEquals( 26250.1, magModel.getHorizontalIntensity(  22 , -132, 2024.5, 64) , 5.0E-02);
	assertEquals( 18702.1, magModel.getHorizontalIntensity( -65 ,   55, 2024.5, 26) , 5.0E-02);
	assertEquals( 15940.8, magModel.getHorizontalIntensity( -21 ,   32, 2024.5, 66) , 5.0E-02);
	assertEquals( 31031.6, magModel.getHorizontalIntensity(   9 , -172, 2024.5, 18) , 5.0E-02);
	assertEquals(  2523.6, magModel.getHorizontalIntensity(  88 ,   26, 2024.5, 63) , 5.0E-02);
	assertEquals( 34062.9, magModel.getHorizontalIntensity(  17 ,    5, 2024.5, 33) , 5.0E-02);
	assertEquals( 31825.9, magModel.getHorizontalIntensity( -18 ,  138, 2024.5, 77) , 5.0E-02);
    }
    /**
     * Test method for d3.env.TSAGeoMag.getNorthIntensity() in nT
     */
    @Test public final void getNorthIntensity() 
    {
	assertEquals(  -575.7, magModel.getNorthIntensity( 89, -121, 2020.0, 28) , 5.0E-02);
	assertEquals(  1518.0, magModel.getNorthIntensity( 80,  -96, 2020.0, 48) , 5.0E-02);
	assertEquals(  1555.6, magModel.getNorthIntensity( 82,   87, 2020.0, 54) , 5.0E-02);
	assertEquals( 24375.3, magModel.getNorthIntensity( 43,   93, 2020.0, 65) , 5.0E-02);
	assertEquals( 21556.3, magModel.getNorthIntensity(-33,  109, 2020.0, 51) , 5.0E-02);
	assertEquals( 14369.9, magModel.getNorthIntensity(-59,   -8, 2020.0, 39) , 5.0E-02);
	assertEquals( 19684.4, magModel.getNorthIntensity(-50, -103, 2020.0,  3) , 5.0E-02);
	assertEquals( 23467.8, magModel.getNorthIntensity(-29, -110, 2020.0, 94) , 5.0E-02);
	assertEquals( 34916.8, magModel.getNorthIntensity( 14,  143, 2020.0, 66) , 5.0E-02);
	assertEquals( 29311.2, magModel.getNorthIntensity(  0,   21, 2020.0, 18) , 5.0E-02);
	
	assertEquals(23948.6, magModel.getNorthIntensity(-36, -137, 2020.5,  6) , 5.0E-02);
	assertEquals(34737.7, magModel.getNorthIntensity( 26,   81, 2020.5, 63) , 5.0E-02);
	assertEquals(22647.3, magModel.getNorthIntensity( 38, -144, 2020.5, 69) , 5.0E-02);
	assertEquals( 8943.1, magModel.getNorthIntensity(-70, -133, 2020.5, 50) , 5.0E-02);
	assertEquals(19571.7, magModel.getNorthIntensity(-52,  -75, 2020.5,  8) , 5.0E-02);
	assertEquals(15247.0, magModel.getNorthIntensity(-66,   17, 2020.5,  8) , 5.0E-02);
	assertEquals(21429.0, magModel.getNorthIntensity(-37,  140, 2020.5, 22) , 5.0E-02);
	assertEquals(28773.9, magModel.getNorthIntensity(-12, -129, 2020.5, 40) , 5.0E-02);
	assertEquals(23414.3, magModel.getNorthIntensity( 33, -118, 2020.5, 44) , 5.0E-02);
	assertEquals(16087.9, magModel.getNorthIntensity(-81,  -67, 2020.5, 50) , 5.0E-02);
	
	assertEquals(13228.0, magModel.getNorthIntensity(-57,    3, 2021.0, 74) , 5.0E-02);
	assertEquals(26037.0, magModel.getNorthIntensity(-24, -122, 2021.0, 46) , 5.0E-02);
	assertEquals(34450.4, magModel.getNorthIntensity( 23,   63, 2021.0, 69) , 5.0E-02);
	assertEquals(30690.1, magModel.getNorthIntensity( -3, -147, 2021.0, 33) , 5.0E-02);
	assertEquals(18352.8, magModel.getNorthIntensity(-72,  -22, 2021.0, 47) , 5.0E-02);
	assertEquals(33213.0, magModel.getNorthIntensity(-14,   99, 2021.0, 62) , 5.0E-02);
	assertEquals( 2408.8, magModel.getNorthIntensity( 86,  -46, 2021.0, 83) , 5.0E-02);
	assertEquals( 2249.5, magModel.getNorthIntensity(-64,   87, 2021.0, 82) , 5.0E-02);
	assertEquals(19327.6, magModel.getNorthIntensity(-19,   43, 2021.0, 34) , 5.0E-02);
	assertEquals( 9198.0, magModel.getNorthIntensity(-81,   40, 2021.0, 56) , 5.0E-02);
	
	assertEquals(39246.6, magModel.getNorthIntensity(  0,   80, 2021.5, 14) , 5.0E-02);
	assertEquals(15995.1, magModel.getNorthIntensity(-82,  -68, 2021.5, 12) , 5.0E-02);
	assertEquals(14159.0, magModel.getNorthIntensity(-46,  -42, 2021.5, 44) , 5.0E-02);
	assertEquals(35896.1, magModel.getNorthIntensity( 17,   52, 2021.5, 43) , 5.0E-02);
	assertEquals(39294.0, magModel.getNorthIntensity( 10,   78, 2021.5, 64) , 5.0E-02);
	assertEquals(24301.2, magModel.getNorthIntensity( 33, -145, 2021.5, 12) , 5.0E-02);
	assertEquals(-9403.6, magModel.getNorthIntensity(-79,  115, 2021.5, 12) , 5.0E-02);
	assertEquals(23592.3, magModel.getNorthIntensity(-33, -114, 2021.5, 14) , 5.0E-02);
	assertEquals(32618.0, magModel.getNorthIntensity( 29,   66, 2021.5, 19) , 5.0E-02);
	assertEquals(32676.0, magModel.getNorthIntensity(-11,  167, 2021.5, 86) , 5.0E-02);
	
	assertEquals(16404.3, magModel.getNorthIntensity(-66,   -5, 2022.0, 37) , 5.0E-02);
	assertEquals( 4532.7, magModel.getNorthIntensity( 72, -115, 2022.0, 67) , 5.0E-02);
	assertEquals(28671.0, magModel.getNorthIntensity( 22,  174, 2022.0, 44) , 5.0E-02);
	assertEquals(20624.8, magModel.getNorthIntensity( 54,  178, 2022.0, 54) , 5.0E-02);
	assertEquals(11344.6, magModel.getNorthIntensity(-43,   50, 2022.0, 57) , 5.0E-02);
	assertEquals(20646.1, magModel.getNorthIntensity(-43, -111, 2022.0, 44) , 5.0E-02);
	assertEquals( 6292.0, magModel.getNorthIntensity(-63,  178, 2022.0, 12) , 5.0E-02);
	assertEquals(25896.5, magModel.getNorthIntensity( 27, -169, 2022.0, 38) , 5.0E-02);
	assertEquals(10098.3, magModel.getNorthIntensity( 59,  -77, 2022.0, 61) , 5.0E-02);
	assertEquals(12663.7, magModel.getNorthIntensity(-47,  -32, 2022.0, 67) , 5.0E-02);
	
	assertEquals(12336.1, magModel.getNorthIntensity(  62,   53, 2022.5,  8) , 5.0E-02);
	assertEquals(16604.7, magModel.getNorthIntensity( -68,   -7, 2022.5, 77) , 5.0E-02);
	assertEquals(33613.6, magModel.getNorthIntensity(  -5,  159, 2022.5, 98) , 5.0E-02);
	assertEquals(23739.9, magModel.getNorthIntensity( -29, -107, 2022.5, 34) , 5.0E-02);
	assertEquals(32938.8, magModel.getNorthIntensity(  27,   65, 2022.5, 60) , 5.0E-02);
	assertEquals(-2661.0, magModel.getNorthIntensity( -72,   95, 2022.5, 73) , 5.0E-02);
	assertEquals(19136.4, magModel.getNorthIntensity( -46,  -85, 2022.5, 96) , 5.0E-02);
	assertEquals(21797.3, magModel.getNorthIntensity( -13,  -59, 2022.5,  0) , 5.0E-02);
	assertEquals(13804.5, magModel.getNorthIntensity(  66, -178, 2022.5, 16) , 5.0E-02);
	assertEquals( 7132.3, magModel.getNorthIntensity( -87,   38, 2022.5, 72) , 5.0E-02);
	
	assertEquals( 30099.4, magModel.getNorthIntensity(  20 , 167, 2023.0, 49) , 5.0E-02);
	assertEquals( 28217.7, magModel.getNorthIntensity(   5 , -13, 2023.0, 71) , 5.0E-02);
	assertEquals( 36804.1, magModel.getNorthIntensity(  14 ,  65, 2023.0, 95) , 5.0E-02);
	assertEquals( 12598.0, magModel.getNorthIntensity( -85 , -79, 2023.0, 86) , 5.0E-02);
	assertEquals( 17694.8, magModel.getNorthIntensity( -36 , -64, 2023.0, 30) , 5.0E-02);
	assertEquals(  2605.8, magModel.getNorthIntensity(  79 , 125, 2023.0, 75) , 5.0E-02);
	assertEquals( 27630.5, magModel.getNorthIntensity(   6 , -32, 2023.0, 21) , 5.0E-02);
	assertEquals( 16998.9, magModel.getNorthIntensity( -76 , -75, 2023.0,  1) , 5.0E-02);
	assertEquals( 13880.3, magModel.getNorthIntensity( -46 , -41, 2023.0, 45) , 5.0E-02);
	assertEquals( 12752.8, magModel.getNorthIntensity( -22 , -21, 2023.0, 11) , 5.0E-02);
	
	assertEquals( 14556.6, magModel.getNorthIntensity(  54 , -120, 2023.5, 28) , 5.0E-02);
	assertEquals(  7015.1, magModel.getNorthIntensity( -58 ,  156, 2023.5, 68) , 5.0E-02);
	assertEquals( 18024.0, magModel.getNorthIntensity( -65 ,  -88, 2023.5, 39) , 5.0E-02);
	assertEquals( 24811.0, magModel.getNorthIntensity( -23 ,   81, 2023.5, 27) , 5.0E-02);
	assertEquals( 29033.7, magModel.getNorthIntensity(  34 ,    0, 2023.5, 11) , 5.0E-02);
	assertEquals(  6836.8, magModel.getNorthIntensity( -62 ,   65, 2023.5, 72) , 5.0E-02);
	assertEquals(  1168.7, magModel.getNorthIntensity(  86 ,   70, 2023.5, 55) , 5.0E-02);
	assertEquals( 28170.0, magModel.getNorthIntensity(  32 ,  163, 2023.5, 59) , 5.0E-02);
	assertEquals( 23356.8, magModel.getNorthIntensity(  48 ,  148, 2023.5, 65) , 5.0E-02);
	assertEquals( 29663.3, magModel.getNorthIntensity(  30 ,   28, 2023.5, 95) , 5.0E-02);
	
	assertEquals( 18099.3, magModel.getNorthIntensity( -60 ,  -59, 2024.0, 95) , 5.0E-02);
	assertEquals( 10615.3, magModel.getNorthIntensity( -70 ,   42, 2024.0, 95) , 5.0E-02);
	assertEquals(    80.9, magModel.getNorthIntensity(  87 , -154, 2024.0, 50) , 5.0E-02);
	assertEquals( 29331.6, magModel.getNorthIntensity(  32 ,   19, 2024.0, 58) , 5.0E-02);
	assertEquals( 28158.7, magModel.getNorthIntensity(  34 ,  -13, 2024.0, 57) , 5.0E-02);
	assertEquals(  8218.0, magModel.getNorthIntensity( -76 ,   49, 2024.0, 38) , 5.0E-02);
	assertEquals( 15431.4, magModel.getNorthIntensity( -50 , -179, 2024.0, 49) , 5.0E-02);
	assertEquals( 12918.7, magModel.getNorthIntensity( -55 , -171, 2024.0, 90) , 5.0E-02);
	assertEquals( 24317.3, magModel.getNorthIntensity(  42 ,  -19, 2024.0, 41) , 5.0E-02);
	assertEquals( 22384.7, magModel.getNorthIntensity(  46 ,  -22, 2024.0, 19) , 5.0E-02);
	
	assertEquals( 28046.9, magModel.getNorthIntensity(  13 , -132, 2024.5, 31) , 5.0E-02);
	assertEquals( 33858.1, magModel.getNorthIntensity(  -2 ,  158, 2024.5, 93) , 5.0E-02);
	assertEquals( 10459.6, magModel.getNorthIntensity( -76 ,   40, 2024.5, 51) , 5.0E-02);
	assertEquals( 25808.9, magModel.getNorthIntensity(  22 , -132, 2024.5, 64) , 5.0E-02);
	assertEquals(  8607.6, magModel.getNorthIntensity( -65 ,   55, 2024.5, 26) , 5.0E-02);
	assertEquals( 15510.7, magModel.getNorthIntensity( -21 ,   32, 2024.5, 66) , 5.0E-02);
	assertEquals( 30615.4, magModel.getNorthIntensity(   9 , -172, 2024.5, 18) , 5.0E-02);
	assertEquals(  2189.6, magModel.getNorthIntensity(  88 ,   26, 2024.5, 63) , 5.0E-02);
	assertEquals( 34060.9, magModel.getNorthIntensity(  17 ,    5, 2024.5, 33) , 5.0E-02);
	assertEquals( 31722.0, magModel.getNorthIntensity( -18 ,  138, 2024.5, 77) , 5.0E-02);
    }
    /**
     * Test method for d3.env.TSAGeoMag.getEastIntensity() in nT
     */
    @Test public final void getEastIntensity() 
    {
	assertEquals( -1396.0, magModel.getEastIntensity( 89, -121, 2020.0, 28) , 5.0E-02);
	assertEquals( -1160.5, magModel.getEastIntensity( 80,  -96, 2020.0, 48) , 5.0E-02);
	assertEquals(  1941.4, magModel.getEastIntensity( 82,   87, 2020.0, 54) , 5.0E-02);
	assertEquals(   303.2, magModel.getEastIntensity( 43,   93, 2020.0, 65) , 5.0E-02);
	assertEquals( -2183.2, magModel.getEastIntensity(-33,  109, 2020.0, 51) , 5.0E-02);
	assertEquals( -4063.3, magModel.getEastIntensity(-59,   -8, 2020.0, 39) , 5.0E-02);
	assertEquals( 10512.2, magModel.getEastIntensity(-50, -103, 2020.0,  3) , 5.0E-02);
	assertEquals(  6650.9, magModel.getEastIntensity(-29, -110, 2020.0, 94) , 5.0E-02);
	assertEquals(    70.2, magModel.getEastIntensity( 14,  143, 2020.0, 66) , 5.0E-02);
	assertEquals(   536.0, magModel.getEastIntensity(  0,   21, 2020.0, 18) , 5.0E-02);
	
	assertEquals( 8791.9, magModel.getEastIntensity(-36, -137, 2020.5,  6) , 5.0E-02);
	assertEquals(  259.2, magModel.getEastIntensity( 26,   81, 2020.5, 63) , 5.0E-02);
	assertEquals( 5390.0, magModel.getEastIntensity( 38, -144, 2020.5, 69) , 5.0E-02);
	assertEquals(13981.7, magModel.getEastIntensity(-70, -133, 2020.5, 50) , 5.0E-02);
	assertEquals( 5387.5, magModel.getEastIntensity(-52,  -75, 2020.5,  8) , 5.0E-02);
	assertEquals(-9734.8, magModel.getEastIntensity(-66,   17, 2020.5,  8) , 5.0E-02);
	assertEquals( 3451.3, magModel.getEastIntensity(-37,  140, 2020.5, 22) , 5.0E-02);
	assertEquals( 5503.9, magModel.getEastIntensity(-12, -129, 2020.5, 40) , 5.0E-02);
	assertEquals( 4748.3, magModel.getEastIntensity( 33, -118, 2020.5, 44) , 5.0E-02);
	assertEquals( 8788.9, magModel.getEastIntensity(-81,  -67, 2020.5, 50) , 5.0E-02);
	
	assertEquals( -5423.3, magModel.getEastIntensity(-57,    3, 2021.0, 74) , 5.0E-02);
	assertEquals(  6501.8, magModel.getEastIntensity(-24, -122, 2021.0, 46) , 5.0E-02);
	assertEquals(   646.9, magModel.getEastIntensity( 23,   63, 2021.0, 69) , 5.0E-02);
	assertEquals(  5265.7, magModel.getEastIntensity( -3, -147, 2021.0, 33) , 5.0E-02);
	assertEquals( -1946.6, magModel.getEastIntensity(-72,  -22, 2021.0, 47) , 5.0E-02);
	assertEquals(  -990.3, magModel.getEastIntensity(-14,   99, 2021.0, 62) , 5.0E-02);
	assertEquals( -1796.2, magModel.getEastIntensity( 86,  -46, 2021.0, 83) , 5.0E-02);
	assertEquals(-13907.0, magModel.getEastIntensity(-64,   87, 2021.0, 82) , 5.0E-02);
	assertEquals( -4933.5, magModel.getEastIntensity(-19,   43, 2021.0, 34) , 5.0E-02);
	assertEquals(-15323.4, magModel.getEastIntensity(-81,   40, 2021.0, 56) , 5.0E-02);
	
	assertEquals(-2338.9, magModel.getEastIntensity(  0,   80, 2021.5, 14) , 5.0E-02);
	assertEquals( 9368.5, magModel.getEastIntensity(-82,  -68, 2021.5, 12) , 5.0E-02);
	assertEquals(-2889.8, magModel.getEastIntensity(-46,  -42, 2021.5, 44) , 5.0E-02);
	assertEquals(  773.7, magModel.getEastIntensity( 17,   52, 2021.5, 43) , 5.0E-02);
	assertEquals(-1172.2, magModel.getEastIntensity( 10,   78, 2021.5, 64) , 5.0E-02);
	assertEquals( 5327.4, magModel.getEastIntensity( 33, -145, 2021.5, 12) , 5.0E-02);
	assertEquals(-8972.3, magModel.getEastIntensity(-79,  115, 2021.5, 12) , 5.0E-02);
	assertEquals( 7712.3, magModel.getEastIntensity(-33, -114, 2021.5, 14) , 5.0E-02);
	assertEquals( 1215.2, magModel.getEastIntensity( 29,   66, 2021.5, 19) , 5.0E-02);
	assertEquals( 5828.1, magModel.getEastIntensity(-11,  167, 2021.5, 86) , 5.0E-02);
	
	assertEquals( -5011.2, magModel.getEastIntensity(-66,   -5, 2022.0, 37) , 5.0E-02);
	assertEquals(  1254.7, magModel.getEastIntensity( 72, -115, 2022.0, 67) , 5.0E-02);
	assertEquals(  3294.9, magModel.getEastIntensity( 22,  174, 2022.0, 44) , 5.0E-02);
	assertEquals(   514.8, magModel.getEastIntensity( 54,  178, 2022.0, 54) , 5.0E-02);
	assertEquals(-12349.5, magModel.getEastIntensity(-43,   50, 2022.0, 57) , 5.0E-02);
	assertEquals(  9330.1, magModel.getEastIntensity(-43, -111, 2022.0, 44) , 5.0E-02);
	assertEquals(  9718.1, magModel.getEastIntensity(-63,  178, 2022.0, 12) , 5.0E-02);
	assertEquals(  3991.3, magModel.getEastIntensity( 27, -169, 2022.0, 38) , 5.0E-02);
	assertEquals( -3208.9, magModel.getEastIntensity( 59,  -77, 2022.0, 61) , 5.0E-02);
	assertEquals( -3178.2, magModel.getEastIntensity(-47,  -32, 2022.0, 67) , 5.0E-02);
	
	assertEquals(  4236.6, magModel.getEastIntensity(  62,   53, 2022.5,  8) , 5.0E-02);
	assertEquals( -4741.2, magModel.getEastIntensity( -68,   -7, 2022.5, 77) , 5.0E-02);
	assertEquals(  4601.1, magModel.getEastIntensity(  -5,  159, 2022.5, 98) , 5.0E-02);
	assertEquals(  6662.3, magModel.getEastIntensity( -29, -107, 2022.5, 34) , 5.0E-02);
	assertEquals(  1025.8, magModel.getEastIntensity(  27,   65, 2022.5, 60) , 5.0E-02);
	assertEquals(-13095.2, magModel.getEastIntensity( -72,   95, 2022.5, 73) , 5.0E-02);
	assertEquals(  6358.2, magModel.getEastIntensity( -46,  -85, 2022.5, 96) , 5.0E-02);
	assertEquals( -6520.6, magModel.getEastIntensity( -13,  -59, 2022.5,  0) , 5.0E-02);
	assertEquals(   463.2, magModel.getEastIntensity(  66, -178, 2022.5, 16) , 5.0E-02);
	assertEquals(-15063.2, magModel.getEastIntensity( -87,   38, 2022.5, 72) , 5.0E-02);
	
	assertEquals(   2737.4, magModel.getEastIntensity(  20 , 167, 2023.0, 49) , 5.0E-02);
	assertEquals(  -3592.6, magModel.getEastIntensity(   5 , -13, 2023.0, 71) , 5.0E-02);
	assertEquals(   -356.8, magModel.getEastIntensity(  14 ,  65, 2023.0, 95) , 5.0E-02);
	assertEquals(  11248.0, magModel.getEastIntensity( -85 , -79, 2023.0, 86) , 5.0E-02);
	assertEquals(  -1198.1, magModel.getEastIntensity( -36 , -64, 2023.0, 30) , 5.0E-02);
	assertEquals(   -676.0, magModel.getEastIntensity(  79 , 125, 2023.0, 75) , 5.0E-02);
	assertEquals(  -7515.0, magModel.getEastIntensity(   6 , -32, 2023.0, 21) , 5.0E-02);
	assertEquals(   9958.1, magModel.getEastIntensity( -76 , -75, 2023.0,  1) , 5.0E-02);
	assertEquals(  -2936.1, magModel.getEastIntensity( -46 , -41, 2023.0, 45) , 5.0E-02);
	assertEquals(  -5710.4, magModel.getEastIntensity( -22 , -21, 2023.0, 11) , 5.0E-02);
	
	assertEquals(   4230.3, magModel.getEastIntensity(  54 , -120, 2023.5, 28) , 5.0E-02);
	assertEquals(   5987.8, magModel.getEastIntensity( -58 ,  156, 2023.5, 68) , 5.0E-02);
	assertEquals(  10347.2, magModel.getEastIntensity( -65 ,  -88, 2023.5, 39) , 5.0E-02);
	assertEquals(  -6176.1, magModel.getEastIntensity( -23 ,   81, 2023.5, 27) , 5.0E-02);
	assertEquals(    545.3, magModel.getEastIntensity(  34 ,    0, 2023.5, 11) , 5.0E-02);
	assertEquals( -16092.9, magModel.getEastIntensity( -62 ,   65, 2023.5, 72) , 5.0E-02);
	assertEquals(   2124.7, magModel.getEastIntensity(  86 ,   70, 2023.5, 55) , 5.0E-02);
	assertEquals(    176.0, magModel.getEastIntensity(  32 ,  163, 2023.5, 59) , 5.0E-02);
	assertEquals(  -3861.2, magModel.getEastIntensity(  48 ,  148, 2023.5, 65) , 5.0E-02);
	assertEquals(   2331.2, magModel.getEastIntensity(  30 ,   28, 2023.5, 95) , 5.0E-02);
	
	assertEquals(   2821.2, magModel.getEastIntensity( -60 ,  -59, 2024.0, 95) , 5.0E-02);
	assertEquals( -14769.3, magModel.getEastIntensity( -70 ,   42, 2024.0, 95) , 5.0E-02);
	assertEquals(   -592.4, magModel.getEastIntensity(  87 , -154, 2024.0, 50) , 5.0E-02);
	assertEquals(   2019.5, magModel.getEastIntensity(  32 ,   19, 2024.0, 58) , 5.0E-02);
	assertEquals(  -1290.8, magModel.getEastIntensity(  34 ,  -13, 2024.0, 57) , 5.0E-02);
	assertEquals( -16491.7, magModel.getEastIntensity( -76 ,   49, 2024.0, 38) , 5.0E-02);
	assertEquals(   9482.7, magModel.getEastIntensity( -50 , -179, 2024.0, 49) , 5.0E-02);
	assertEquals(  10118.6, magModel.getEastIntensity( -55 , -171, 2024.0, 90) , 5.0E-02);
	assertEquals(  -2127.0, magModel.getEastIntensity(  42 ,  -19, 2024.0, 41) , 5.0E-02);
	assertEquals(  -2590.4, magModel.getEastIntensity(  46 ,  -22, 2024.0, 19) , 5.0E-02);
	
	assertEquals(   4548.8, magModel.getEastIntensity(  13 , -132, 2024.5, 31) , 5.0E-02);
	assertEquals(   4253.5, magModel.getEastIntensity(  -2 ,  158, 2024.5, 93) , 5.0E-02);
	assertEquals( -15294.7, magModel.getEastIntensity( -76 ,   40, 2024.5, 51) , 5.0E-02);
	assertEquals(   4792.5, magModel.getEastIntensity(  22 , -132, 2024.5, 64) , 5.0E-02);
	assertEquals( -16603.5, magModel.getEastIntensity( -65 ,   55, 2024.5, 26) , 5.0E-02);
	assertEquals(  -3677.9, magModel.getEastIntensity( -21 ,   32, 2024.5, 66) , 5.0E-02);
	assertEquals(   5065.5, magModel.getEastIntensity(   9 , -172, 2024.5, 18) , 5.0E-02);
	assertEquals(   1254.6, magModel.getEastIntensity(  88 ,   26, 2024.5, 63) , 5.0E-02);
	assertEquals(    362.9, magModel.getEastIntensity(  17 ,    5, 2024.5, 33) , 5.0E-02);
	assertEquals(   2569.6, magModel.getEastIntensity( -18 ,  138, 2024.5, 77) , 5.0E-02);
    }
    /**
     * Test method for d3.env.TSAGeoMag.getVerticalIntensity()
     */
    @Test public final void getVerticalIntensity() 
    {
	assertEquals(  56082.3, magModel.getVerticalIntensity( 89, -121, 2020.0, 28) , 5.0E-02);
	assertEquals(  55671.9, magModel.getVerticalIntensity( 80,  -96, 2020.0, 48) , 5.0E-02);
	assertEquals(  56520.5, magModel.getVerticalIntensity( 82,   87, 2020.0, 54) , 5.0E-02);
	assertEquals(  49691.4, magModel.getVerticalIntensity( 43,   93, 2020.0, 65) , 5.0E-02);
	assertEquals( -52676.0, magModel.getVerticalIntensity(-33,  109, 2020.0, 51) , 5.0E-02);
	assertEquals( -24679.0, magModel.getVerticalIntensity(-59,   -8, 2020.0, 39) , 5.0E-02);
	assertEquals( -31883.6, magModel.getVerticalIntensity(-50, -103, 2020.0,  3) , 5.0E-02);
	assertEquals( -19320.7, magModel.getVerticalIntensity(-29, -110, 2020.0, 94) , 5.0E-02);
	assertEquals(   8114.9, magModel.getVerticalIntensity( 14,  143, 2020.0, 66) , 5.0E-02);
	assertEquals( -14589.0, magModel.getVerticalIntensity(  0,   21, 2020.0, 18) , 5.0E-02);
	
	assertEquals(-32897.6, magModel.getVerticalIntensity(-36, -137, 2020.5,  6) , 5.0E-02);
	assertEquals( 30023.4, magModel.getVerticalIntensity( 26,   81, 2020.5, 63) , 5.0E-02);
	assertEquals( 35831.9, magModel.getVerticalIntensity( 38, -144, 2020.5, 69) , 5.0E-02);
	assertEquals(-51628.5, magModel.getVerticalIntensity(-70, -133, 2020.5, 50) , 5.0E-02);
	assertEquals(-23769.0, magModel.getVerticalIntensity(-52,  -75, 2020.5,  8) , 5.0E-02);
	assertEquals(-31062.0, magModel.getVerticalIntensity(-66,   17, 2020.5,  8) , 5.0E-02);
	assertEquals(-55415.6, magModel.getVerticalIntensity(-37,  140, 2020.5, 22) , 5.0E-02);
	assertEquals( -8221.8, magModel.getVerticalIntensity(-12, -129, 2020.5, 40) , 5.0E-02);
	assertEquals( 38184.5, magModel.getVerticalIntensity( 33, -118, 2020.5, 44) , 5.0E-02);
	assertEquals(-44780.8, magModel.getVerticalIntensity(-81,  -67, 2020.5, 50) , 5.0E-02);
	
	assertEquals(-23859.2, magModel.getVerticalIntensity(-57,    3, 2021.0, 74) , 5.0E-02);
	assertEquals(-18297.4, magModel.getVerticalIntensity(-24, -122, 2021.0, 46) , 5.0E-02);
	assertEquals( 24869.2, magModel.getVerticalIntensity( 23,   63, 2021.0, 69) , 5.0E-02);
	assertEquals( -1277.4, magModel.getVerticalIntensity( -3, -147, 2021.0, 33) , 5.0E-02);
	assertEquals(-33665.0, magModel.getVerticalIntensity(-72,  -22, 2021.0, 47) , 5.0E-02);
	assertEquals(-33354.0, magModel.getVerticalIntensity(-14,   99, 2021.0, 62) , 5.0E-02);
	assertEquals( 54184.7, magModel.getVerticalIntensity( 86,  -46, 2021.0, 83) , 5.0E-02);
	assertEquals(-53526.9, magModel.getVerticalIntensity(-64,   87, 2021.0, 82) , 5.0E-02);
	assertEquals(-25969.5, magModel.getVerticalIntensity(-19,   43, 2021.0, 34) , 5.0E-02);
	assertEquals(-45453.8, magModel.getVerticalIntensity(-81,   40, 2021.0, 56) , 5.0E-02);
	
	assertEquals( -12258.0, magModel.getVerticalIntensity(  0,   80, 2021.5, 14) , 5.0E-02);
	assertEquals( -46308.7, magModel.getVerticalIntensity(-82,  -68, 2021.5, 12) , 5.0E-02);
	assertEquals( -19762.2, magModel.getVerticalIntensity(-46,  -42, 2021.5, 44) , 5.0E-02);
	assertEquals(  15885.6, magModel.getVerticalIntensity( 17,   52, 2021.5, 43) , 5.0E-02);
	assertEquals(   5088.1, magModel.getVerticalIntensity( 10,   78, 2021.5, 64) , 5.0E-02);
	assertEquals(  32429.3, magModel.getVerticalIntensity( 33, -145, 2021.5, 12) , 5.0E-02);
	assertEquals( -58271.0, magModel.getVerticalIntensity(-79,  115, 2021.5, 12) , 5.0E-02);
	assertEquals( -24163.1, magModel.getVerticalIntensity(-33, -114, 2021.5, 14) , 5.0E-02);
	assertEquals(  33763.7, magModel.getVerticalIntensity( 29,   66, 2021.5, 19) , 5.0E-02);
	assertEquals( -20299.1, magModel.getVerticalIntensity(-11,  167, 2021.5, 86) , 5.0E-02);
	
	assertEquals( -28849.5, magModel.getVerticalIntensity(-66,   -5, 2022.0, 37) , 5.0E-02);
	assertEquals(  55923.4, magModel.getVerticalIntensity( 72, -115, 2022.0, 67) , 5.0E-02);
	assertEquals(  17967.2, magModel.getVerticalIntensity( 22,  174, 2022.0, 44) , 5.0E-02);
	assertEquals(  45076.8, magModel.getVerticalIntensity( 54,  178, 2022.0, 54) , 5.0E-02);
	assertEquals( -32850.3, magModel.getVerticalIntensity(-43,   50, 2022.0, 57) , 5.0E-02);
	assertEquals( -29747.5, magModel.getVerticalIntensity(-43, -111, 2022.0, 44) , 5.0E-02);
	assertEquals( -61429.1, magModel.getVerticalIntensity(-63,  178, 2022.0, 12) , 5.0E-02);
	assertEquals(  24097.4, magModel.getVerticalIntensity( 27, -169, 2022.0, 38) , 5.0E-02);
	assertEquals(  54735.3, magModel.getVerticalIntensity( 59,  -77, 2022.0, 61) , 5.0E-02);
	assertEquals( -20600.9, magModel.getVerticalIntensity(-47,  -32, 2022.0, 67) , 5.0E-02);
	
	assertEquals(  54498.1, magModel.getVerticalIntensity(  62,   53, 2022.5,  8) , 5.0E-02);
	assertEquals( -29908.6, magModel.getVerticalIntensity( -68,   -7, 2022.5, 77) , 5.0E-02);
	assertEquals( -14426.9, magModel.getVerticalIntensity(  -5,  159, 2022.5, 98) , 5.0E-02);
	assertEquals( -19023.5, magModel.getVerticalIntensity( -29, -107, 2022.5, 34) , 5.0E-02);
	assertEquals(  30561.3, magModel.getVerticalIntensity(  27,   65, 2022.5, 60) , 5.0E-02);
	assertEquals( -55423.4, magModel.getVerticalIntensity( -72,   95, 2022.5, 73) , 5.0E-02);
	assertEquals( -21915.4, magModel.getVerticalIntensity( -46,  -85, 2022.5, 96) , 5.0E-02);
	assertEquals(  -5425.9, magModel.getVerticalIntensity( -13,  -59, 2022.5,  0) , 5.0E-02);
	assertEquals(  54055.4, magModel.getVerticalIntensity(  66, -178, 2022.5, 16) , 5.0E-02);
	assertEquals( -48550.5, magModel.getVerticalIntensity( -87,   38, 2022.5, 72) , 5.0E-02);
	
	assertEquals(   15301.2, magModel.getVerticalIntensity(  20 , 167, 2023.0, 49) , 5.0E-02);
	assertEquals(   -8905.8, magModel.getVerticalIntensity(   5 , -13, 2023.0, 71) , 5.0E-02);
	assertEquals(   11616.0, magModel.getVerticalIntensity(  14 ,  65, 2023.0, 95) , 5.0E-02);
	assertEquals(  -47331.2, magModel.getVerticalIntensity( -85 , -79, 2023.0, 86) , 5.0E-02);
	assertEquals(  -14566.5, magModel.getVerticalIntensity( -36 , -64, 2023.0, 30) , 5.0E-02);
	assertEquals(   57085.9, magModel.getVerticalIntensity(  79 , 125, 2023.0, 75) , 5.0E-02);
	assertEquals(   -3646.9, magModel.getVerticalIntensity(   6 , -32, 2023.0, 21) , 5.0E-02);
	assertEquals(  -42873.8, magModel.getVerticalIntensity( -76 , -75, 2023.0,  1) , 5.0E-02);
	assertEquals(  -19853.0, magModel.getVerticalIntensity( -46 , -41, 2023.0, 45) , 5.0E-02);
	assertEquals(  -21372.4, magModel.getVerticalIntensity( -22 , -21, 2023.0, 11) , 5.0E-02);
	
	assertEquals(  52945.6, magModel.getVerticalIntensity(  54 , -120, 2023.5, 28) , 5.0E-02);
	assertEquals( -62459.5, magModel.getVerticalIntensity( -58 ,  156, 2023.5, 68) , 5.0E-02);
	assertEquals( -36415.6, magModel.getVerticalIntensity( -65 ,  -88, 2023.5, 39) , 5.0E-02);
	assertEquals( -41759.2, magModel.getVerticalIntensity( -23 ,   81, 2023.5, 27) , 5.0E-02);
	assertEquals(  30807.0, magModel.getVerticalIntensity(  34 ,    0, 2023.5, 11) , 5.0E-02);
	assertEquals( -44111.8, magModel.getVerticalIntensity( -62 ,   65, 2023.5, 72) , 5.0E-02);
	assertEquals(  55750.6, magModel.getVerticalIntensity(  86 ,   70, 2023.5, 55) , 5.0E-02);
	assertEquals(  26318.3, magModel.getVerticalIntensity(  32 ,  163, 2023.5, 59) , 5.0E-02);
	assertEquals(  43968.0, magModel.getVerticalIntensity(  48 ,  148, 2023.5, 65) , 5.0E-02);
	assertEquals(  28857.6, magModel.getVerticalIntensity(  30 ,   28, 2023.5, 95) , 5.0E-02);
	
	assertEquals(-26193.2, magModel.getVerticalIntensity( -60 ,  -59, 2024.0, 95) , 5.0E-02);
	assertEquals(-38293.4, magModel.getVerticalIntensity( -70 ,   42, 2024.0, 95) , 5.0E-02);
	assertEquals( 55904.6, magModel.getVerticalIntensity(  87 , -154, 2024.0, 50) , 5.0E-02);
	assertEquals( 30329.8, magModel.getVerticalIntensity(  32 ,   19, 2024.0, 58) , 5.0E-02);
	assertEquals( 29015.5, magModel.getVerticalIntensity(  34 ,  -13, 2024.0, 57) , 5.0E-02);
	assertEquals(-44260.7, magModel.getVerticalIntensity( -76 ,   49, 2024.0, 38) , 5.0E-02);
	assertEquals(-53818.3, magModel.getVerticalIntensity( -50 , -179, 2024.0, 49) , 5.0E-02);
	assertEquals(-53373.5, magModel.getVerticalIntensity( -55 , -171, 2024.0, 90) , 5.0E-02);
	assertEquals( 36981.3, magModel.getVerticalIntensity(  42 ,  -19, 2024.0, 41) , 5.0E-02);
	assertEquals( 40713.3, magModel.getVerticalIntensity(  46 ,  -22, 2024.0, 19) , 5.0E-02);
	
	assertEquals(  17417.2, magModel.getVerticalIntensity(  13 , -132, 2024.5, 31) , 5.0E-02);
	assertEquals( -10940.3, magModel.getVerticalIntensity(  -2 ,  158, 2024.5, 93) , 5.0E-02);
	assertEquals( -42141.5, magModel.getVerticalIntensity( -76 ,   40, 2024.5, 51) , 5.0E-02);
	assertEquals(  25239.1, magModel.getVerticalIntensity(  22 , -132, 2024.5, 64) , 5.0E-02);
	assertEquals( -41366.0, magModel.getVerticalIntensity( -65 ,   55, 2024.5, 26) , 5.0E-02);
	assertEquals( -24502.7, magModel.getVerticalIntensity( -21 ,   32, 2024.5, 66) , 5.0E-02);
	assertEquals(   8768.5, magModel.getVerticalIntensity(   9 , -172, 2024.5, 18) , 5.0E-02);
	assertEquals(  55156.1, magModel.getVerticalIntensity(  88 ,   26, 2024.5, 63) , 5.0E-02);
	assertEquals(   8230.6, magModel.getVerticalIntensity(  17 ,    5, 2024.5, 33) , 5.0E-02);
	assertEquals( -34986.2, magModel.getVerticalIntensity( -18 ,  138, 2024.5, 77) , 5.0E-02);
    }
    /**
     * Test method for d3.env.TSAGeoMag.getIntensity()
     */
    @Test public final void getIntensity()
    {
	assertEquals( 56102.7, magModel.getIntensity( 89, -121, 2020.0, 28) , 5.0E-02);
	assertEquals( 55704.7, magModel.getIntensity( 80,  -96, 2020.0, 48) , 5.0E-02);
	assertEquals( 56575.2, magModel.getIntensity( 82,   87, 2020.0, 54) , 5.0E-02);
	assertEquals( 55348.7, magModel.getIntensity( 43,   93, 2020.0, 65) , 5.0E-02);
	assertEquals( 56957.9, magModel.getIntensity(-33,  109, 2020.0, 51) , 5.0E-02);
	assertEquals( 28845.4, magModel.getIntensity(-59,   -8, 2020.0, 39) , 5.0E-02);
	assertEquals( 38917.2, magModel.getIntensity(-50, -103, 2020.0,  3) , 5.0E-02);
	assertEquals( 31116.9, magModel.getIntensity(-29, -110, 2020.0, 94) , 5.0E-02);
	assertEquals( 35847.5, magModel.getIntensity( 14,  143, 2020.0, 66) , 5.0E-02);
	assertEquals( 32745.6, magModel.getIntensity(  0,   21, 2020.0, 18) , 5.0E-02);
	
	assertEquals(41630.3, magModel.getIntensity(-36, -137, 2020.5,  6) , 5.0E-02);
	assertEquals(45914.9, magModel.getIntensity( 26,   81, 2020.5, 63) , 5.0E-02);
	assertEquals(42730.3, magModel.getIntensity( 38, -144, 2020.5, 69) , 5.0E-02);
	assertEquals(54230.7, magModel.getIntensity(-70, -133, 2020.5, 50) , 5.0E-02);
	assertEquals(31257.7, magModel.getIntensity(-52,  -75, 2020.5,  8) , 5.0E-02);
	assertEquals(35945.6, magModel.getIntensity(-66,   17, 2020.5,  8) , 5.0E-02);
	assertEquals(59514.7, magModel.getIntensity(-37,  140, 2020.5, 22) , 5.0E-02);
	assertEquals(30427.4, magModel.getIntensity(-12, -129, 2020.5, 40) , 5.0E-02);
	assertEquals(45042.6, magModel.getIntensity( 33, -118, 2020.5, 44) , 5.0E-02);
	assertEquals(48387.8, magModel.getIntensity(-81,  -67, 2020.5, 50) , 5.0E-02);
	
	assertEquals(27814.7, magModel.getIntensity(-57,    3, 2021.0, 74) , 5.0E-02);
	assertEquals(32480.6, magModel.getIntensity(-24, -122, 2021.0, 46) , 5.0E-02);
	assertEquals(42493.9, magModel.getIntensity( 23,   63, 2021.0, 69) , 5.0E-02);
	assertEquals(31164.8, magModel.getIntensity( -3, -147, 2021.0, 33) , 5.0E-02);
	assertEquals(38392.0, magModel.getIntensity(-72,  -22, 2021.0, 47) , 5.0E-02);
	assertEquals(47080.5, magModel.getIntensity(-14,   99, 2021.0, 62) , 5.0E-02);
	assertEquals(54268.0, magModel.getIntensity( 86,  -46, 2021.0, 83) , 5.0E-02);
	assertEquals(55349.8, magModel.getIntensity(-64,   87, 2021.0, 82) , 5.0E-02);
	assertEquals(32746.2, magModel.getIntensity(-19,   43, 2021.0, 34) , 5.0E-02);
	assertEquals(48841.2, magModel.getIntensity(-81,   40, 2021.0, 56) , 5.0E-02);
	
	assertEquals( 41182.8, magModel.getIntensity(  0,   80, 2021.5, 14) , 5.0E-02);
	assertEquals( 49880.9, magModel.getIntensity(-82,  -68, 2021.5, 12) , 5.0E-02);
	assertEquals( 24482.1, magModel.getIntensity(-46,  -42, 2021.5, 44) , 5.0E-02);
	assertEquals( 39261.7, magModel.getIntensity( 17,   52, 2021.5, 43) , 5.0E-02);
	assertEquals( 39639.4, magModel.getIntensity( 10,   78, 2021.5, 64) , 5.0E-02);
	assertEquals( 40872.8, magModel.getIntensity( 33, -145, 2021.5, 12) , 5.0E-02);
	assertEquals( 59702.9, magModel.getIntensity(-79,  115, 2021.5, 12) , 5.0E-02);
	assertEquals( 34640.0, magModel.getIntensity(-33, -114, 2021.5, 14) , 5.0E-02);
	assertEquals( 46961.7, magModel.getIntensity( 29,   66, 2021.5, 19) , 5.0E-02);
	assertEquals( 38906.8, magModel.getIntensity(-11,  167, 2021.5, 86) , 5.0E-02);
	
	assertEquals( 33563.5, magModel.getIntensity(-66,   -5, 2022.0, 37) , 5.0E-02);
	assertEquals( 56120.8, magModel.getIntensity( 72, -115, 2022.0, 67) , 5.0E-02);
	assertEquals( 33995.6, magModel.getIntensity( 22,  174, 2022.0, 44) , 5.0E-02);
	assertEquals( 49573.8, magModel.getIntensity( 54,  178, 2022.0, 54) , 5.0E-02);
	assertEquals( 36883.0, magModel.getIntensity(-43,   50, 2022.0, 57) , 5.0E-02);
	assertEquals( 37392.8, magModel.getIntensity(-43, -111, 2022.0, 44) , 5.0E-02);
	assertEquals( 62510.5, magModel.getIntensity(-63,  178, 2022.0, 12) , 5.0E-02);
	assertEquals( 35598.4, magModel.getIntensity( 27, -169, 2022.0, 38) , 5.0E-02);
	assertEquals( 55751.4, magModel.getIntensity( 59,  -77, 2022.0, 61) , 5.0E-02);
	assertEquals( 24389.9, magModel.getIntensity(-47,  -32, 2022.0, 67) , 5.0E-02);
	
	assertEquals( 56037.2, magModel.getIntensity(  62,   53, 2022.5,  8) , 5.0E-02);
	assertEquals( 34535.8, magModel.getIntensity( -68,   -7, 2022.5, 77) , 5.0E-02);
	assertEquals( 36867.1, magModel.getIntensity(  -5,  159, 2022.5, 98) , 5.0E-02);
	assertEquals( 31142.6, magModel.getIntensity( -29, -107, 2022.5, 34) , 5.0E-02);
	assertEquals( 44944.6, magModel.getIntensity(  27,   65, 2022.5, 60) , 5.0E-02);
	assertEquals( 57011.5, magModel.getIntensity( -72,   95, 2022.5, 73) , 5.0E-02);
	assertEquals( 29781.1, magModel.getIntensity( -46,  -85, 2022.5, 96) , 5.0E-02);
	assertEquals( 23389.8, magModel.getIntensity( -13,  -59, 2022.5,  0) , 5.0E-02);
	assertEquals( 55792.1, magModel.getIntensity(  66, -178, 2022.5, 16) , 5.0E-02);
	assertEquals( 51331.5, magModel.getIntensity( -87,   38, 2022.5, 72) , 5.0E-02);
	
	assertEquals( 33876.1, magModel.getIntensity(  20 , 167, 2023.0, 49) , 5.0E-02);
	assertEquals( 29807.1, magModel.getIntensity(   5 , -13, 2023.0, 71) , 5.0E-02);
	assertEquals( 38595.3, magModel.getIntensity(  14 ,  65, 2023.0, 95) , 5.0E-02);
	assertEquals( 50254.0, magModel.getIntensity( -85 , -79, 2023.0, 86) , 5.0E-02);
	assertEquals( 22950.5, magModel.getIntensity( -36 , -64, 2023.0, 30) , 5.0E-02);
	assertEquals( 57149.3, magModel.getIntensity(  79 , 125, 2023.0, 75) , 5.0E-02);
	assertEquals( 28865.6, magModel.getIntensity(   6 , -32, 2023.0, 21) , 5.0E-02);
	assertEquals( 47183.6, magModel.getIntensity( -76 , -75, 2023.0,  1) , 5.0E-02);
	assertEquals( 24401.3, magModel.getIntensity( -46 , -41, 2023.0, 45) , 5.0E-02);
	assertEquals( 25534.7, magModel.getIntensity( -22 , -21, 2023.0, 11) , 5.0E-02);
	
	assertEquals(55072.9, magModel.getIntensity(  54 , -120, 2023.5, 28) , 5.0E-02);
	assertEquals(63136.8, magModel.getIntensity( -58 ,  156, 2023.5, 68) , 5.0E-02);
	assertEquals(41928.8, magModel.getIntensity( -65 ,  -88, 2023.5, 39) , 5.0E-02);
	assertEquals(48965.0, magModel.getIntensity( -23 ,   81, 2023.5, 27) , 5.0E-02);
	assertEquals(42335.9, magModel.getIntensity(  34 ,    0, 2023.5, 11) , 5.0E-02);
	assertEquals(47450.8, magModel.getIntensity( -62 ,   65, 2023.5, 72) , 5.0E-02);
	assertEquals(55803.4, magModel.getIntensity(  86 ,   70, 2023.5, 55) , 5.0E-02);
	assertEquals(38551.7, magModel.getIntensity(  32 ,  163, 2023.5, 59) , 5.0E-02);
	assertEquals(49936.3, magModel.getIntensity(  48 ,  148, 2023.5, 65) , 5.0E-02);
	assertEquals(41450.1, magModel.getIntensity(  30 ,   28, 2023.5, 95) , 5.0E-02);
	
	assertEquals(31962.9, magModel.getIntensity( -60 ,  -59, 2024.0, 95) , 5.0E-02);
	assertEquals(42393.4, magModel.getIntensity( -70 ,   42, 2024.0, 95) , 5.0E-02);
	assertEquals(55907.8, magModel.getIntensity(  87 , -154, 2024.0, 50) , 5.0E-02);
	assertEquals(42241.2, magModel.getIntensity(  32 ,   19, 2024.0, 58) , 5.0E-02);
	assertEquals(40453.4, magModel.getIntensity(  34 ,  -13, 2024.0, 57) , 5.0E-02);
	assertEquals(47942.9, magModel.getIntensity( -76 ,   49, 2024.0, 38) , 5.0E-02);
	assertEquals(56784.4, magModel.getIntensity( -50 , -179, 2024.0, 49) , 5.0E-02);
	assertEquals(55839.2, magModel.getIntensity( -55 , -171, 2024.0, 90) , 5.0E-02);
	assertEquals(44311.1, magModel.getIntensity(  42 ,  -19, 2024.0, 41) , 5.0E-02);
	assertEquals(46533.4, magModel.getIntensity(  46 ,  -22, 2024.0, 19) , 5.0E-02);
	
	assertEquals( 33326.9, magModel.getIntensity(  13 , -132, 2024.5, 31) , 5.0E-02);
	assertEquals( 35835.1, magModel.getIntensity(  -2 ,  158, 2024.5, 93) , 5.0E-02);
	assertEquals( 46035.2, magModel.getIntensity( -76 ,   40, 2024.5, 51) , 5.0E-02);
	assertEquals( 36415.3, magModel.getIntensity(  22 , -132, 2024.5, 64) , 5.0E-02);
	assertEquals( 45397.3, magModel.getIntensity( -65 ,   55, 2024.5, 26) , 5.0E-02);
	assertEquals( 29231.7, magModel.getIntensity( -21 ,   32, 2024.5, 66) , 5.0E-02);
	assertEquals( 32246.7, magModel.getIntensity(   9 , -172, 2024.5, 18) , 5.0E-02);
	assertEquals( 55213.8, magModel.getIntensity(  88 ,   26, 2024.5, 63) , 5.0E-02);
	assertEquals( 35043.1, magModel.getIntensity(  17 ,    5, 2024.5, 33) , 5.0E-02);
	assertEquals( 47296.1, magModel.getIntensity( -18 ,  138, 2024.5, 77) , 5.0E-02);
    }
    
    /**
     *  test method for {@link d3.env.TSAGeoMag#decimalYear(GregorianCalendar)}
     */
    @Test
    public final void decimalYear()
    {
	TSAGeoMag mag = new TSAGeoMag();
	
	GregorianCalendar cal = new GregorianCalendar(2010, 0, 0);
	assertEquals(2010.0, mag.decimalYear(cal), 0.0);
	
	GregorianCalendar cal2 = new GregorianCalendar(2012, 6, 1);  // the full day of July 1, 0 hours into 2 July
	assertTrue(cal2.isLeapYear(2012));
	assertEquals(2012.5, mag.decimalYear(cal2), 0.0);
	
	cal2 = new GregorianCalendar(2013, 3, 13);
	assertFalse(cal2.isLeapYear(2013));
	assertEquals(2013.282, mag.decimalYear(cal2), 0.0005);
    }
}
